<?php
$host='localhost';
$database='mydb';
$user='root';
$password='';

$conn=new PDO("mysql:host=".$host.";dbname=".$database,$user,$password);

$query="select * from cds";
$statement=$conn->prepare($query);
$statement->execute();
echo $statement->rowcount();
?>